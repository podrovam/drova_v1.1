function burgerTransform(x) {
  x.classList.toggle("change");
}





// Get all tabs
var tabs_items = document.querySelectorAll(".tabs");

// Loop through all tabs
tabs_items.forEach(function (tabs) {
  // Set variable
  var controls = tabs.querySelector(".tabs__control");
  var tab = controls.querySelectorAll(".tabs__tab");
  var contents = tabs.querySelector(".tabs__contents");
  var content = contents.querySelectorAll(".tabs__content");

  // Loop through all tabs
  tab.forEach(function (item) {
    item.onclick = function (e) {
      e.preventDefault();

      // Get clicked tab ID
      var tabId = item.dataset.tab;

      // Set current tab
      tab.forEach(function (item) {
        if (tabId == item.dataset.tab) {
          item.classList.add("tabs__tab--current");
          item.setAttribute('aria-selected','true');
          item.removeAttribute('tabindex','-1');
        } else {
          item.classList.remove("tabs__tab--current");
          item.setAttribute('aria-selected','false');
          item.setAttribute('tabindex','-1');
        }
      });

      // Set current content
      content.forEach(function (item) {
        if (tabId == item.dataset.tabContent) {
          item.classList.add("tabs__content--current");
          item.removeAttribute('hidden','hidden');
        } else {
          item.classList.remove("tabs__content--current");
          item.setAttribute('hidden','hidden');
        }
      });
    };
  });
});
